# quickcheck-dynamic

A library for testing stateful programs using dynamic logic.
