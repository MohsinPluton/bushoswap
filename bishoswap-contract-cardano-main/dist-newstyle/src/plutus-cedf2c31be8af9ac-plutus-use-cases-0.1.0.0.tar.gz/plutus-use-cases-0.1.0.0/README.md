# Plutus use cases

This package contains a number of worked use cases as Plutus Applications.

Source for the applications can be found in the `src` folder, and tests in `test`.
