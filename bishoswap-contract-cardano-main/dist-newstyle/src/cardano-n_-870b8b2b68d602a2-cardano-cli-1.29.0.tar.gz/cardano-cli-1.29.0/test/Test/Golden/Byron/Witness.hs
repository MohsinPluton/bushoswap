{-# LANGUAGE OverloadedStrings #-}

module Test.Golden.Byron.Witness
  ( golden_byronWitness
  ) where

import           Cardano.Prelude
import           Hedgehog (Property)

{- HLINT ignore "Use camelCase" -}

golden_byronWitness :: Property
golden_byronWitness = panic "TODO"
